# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyschval']

package_data = \
{'': ['*']}

install_requires = \
['saxonche>=12.0.0,<13.0.0']

setup_kwargs = {
    'name': 'pyschval',
    'version': '0.1.0',
    'description': 'A python based wrapper around saxon and schxslt',
    'long_description': 'None',
    'author': 'Bpolitycki',
    'author_email': 'bastian.politycki@unisg.ch',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
